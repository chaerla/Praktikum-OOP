#include "PremiumUser.h"
#include <iostream>
using namespace std;

PremiumUser::PremiumUser(char *name) : User(name)
{
    num_of_music_downloaded = 0;
    active = true;
}

void PremiumUser::downloadMusic(char *music)
{
    if (active)
    {
        num_of_music_downloaded++;
        cout << "Music Downloaded: " << music << endl;
    }
    else
    {
        cout << "Activate premium account to download music" << endl;
    }
}

void PremiumUser::inactivatePremium()
{
    active = false;
}

void PremiumUser::activatePremium()
{
    active = true;
}

int PremiumUser::getNumOfMusicDownloaded() const
{
    return num_of_music_downloaded;
}

bool PremiumUser::getPremiumStatus() const
{
    return active;
}
