#include "User.h"
#include <iostream>

using namespace std;

int User::n_user = 0;

User::User(char *name)
{
    this->name = new char[strlen(name)];
    strcpy(this->name, name);
    music_list = nullptr;
    num_of_favourite_music = 0;
    n_user++;
}

User::User(const User &other)
{
    this->name = new char[strlen(other.name)];
    strcpy(this->name, other.name);
    music_list = new char *[other.num_of_favourite_music];
    num_of_favourite_music = other.num_of_favourite_music;
    for (int i = 0; i < num_of_favourite_music; i++)
    {
        this->music_list[i] = new char[strlen(other.music_list[i])];
        strcpy(this->music_list[i], other.music_list[i]);
    }
    n_user++;
}

User::~User()
{
    delete[] name;
    delete[] music_list;
    cout << "User " << this->name << " deleted\n";
}

void User::addFavouriteMusic(char *music)
{
    char **temp_music_list = new char *[num_of_favourite_music + 1];
    for (int i = 0; i < num_of_favourite_music; i++)
    {
        temp_music_list[i] = new char[strlen(music_list[i])];
        strcpy(temp_music_list[i], music_list[i]);
    }
    delete[] music_list;
    music_list = temp_music_list;
    temp_music_list[num_of_favourite_music] = new char[strlen(music)];
    strcpy(temp_music_list[num_of_favourite_music], music);
    num_of_favourite_music++;
}

void User::deleteFavouriteMusic(char *music)
{
    if (num_of_favourite_music > 0)
    {
        char **temp_music_list = new char *[num_of_favourite_music];
        int j = 0;
        for (int i = 0; i < num_of_favourite_music; i++)
        {
            if ((strcmp(music_list[i], music)))
            {
                temp_music_list[j] = new char[strlen(music_list[i])];
                strcpy(temp_music_list[j], music_list[i]);
                j++;
            }
            else
            {
                num_of_favourite_music--;
            }
        }
        delete[] music_list;
        music_list = temp_music_list;
    }
}

void User::setName(char *newName)
{
    this->name = new char[strlen(newName)];
    strcpy(this->name, newName);
}

char *User::getName() const
{
    return this->name;
}

int User::getNumOfFavouriteMusic() const
{
    return this->num_of_favourite_music;
}

void User::viewMusicList() const
{
    if (num_of_favourite_music > 0)
    {
        for (int i = 0; i < num_of_favourite_music; i++)
        {
            cout << i + 1 << ". " << music_list[i] << endl;
        }
    }
    else
    {
        cout << "No music in your favourite list" << endl;
    }
}

int User::getNumOfUser()
{
    return User::n_user;
}