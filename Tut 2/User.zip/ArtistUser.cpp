#include "ArtistUser.h"
#include <iostream>

using namespace std;

int ArtistUser::num_of_artist = 0;

ArtistUser::ArtistUser(char *name) : User(name)
{
    num_of_music_uploaded = 0;
    uploaded_music_list = nullptr;
    num_of_artist++;
}

ArtistUser::ArtistUser(const ArtistUser &other) : User(other)
{
    uploaded_music_list = new char *[other.num_of_music_uploaded];
    num_of_music_uploaded = other.num_of_music_uploaded;
    for (int i = 0; i < num_of_music_uploaded; i++)
    {
        this->uploaded_music_list[i] = new char[strlen(other.uploaded_music_list[i])];
        strcpy(this->uploaded_music_list[i], other.uploaded_music_list[i]);
    }
    num_of_artist++;
}

ArtistUser::~ArtistUser()
{
    delete[] uploaded_music_list;
    cout << "Artist user " << this->name << " deleted\n";
}

void ArtistUser::uploadMusic(char *music)
{
    char **temp_uploaded_music_list = new char *[num_of_music_uploaded + 1];
    for (int i = 0; i < num_of_music_uploaded; i++)
    {
        temp_uploaded_music_list[i] = new char[strlen(uploaded_music_list[i])];
        strcpy(temp_uploaded_music_list[i], uploaded_music_list[i]);
    }
    delete[] uploaded_music_list;
    uploaded_music_list = temp_uploaded_music_list;
    temp_uploaded_music_list[num_of_music_uploaded] = new char[strlen(music)];
    strcpy(temp_uploaded_music_list[num_of_music_uploaded], music);
    num_of_music_uploaded++;
}

void ArtistUser::deleteUploadedMusic(char *music)
{
    if (num_of_music_uploaded > 0)
    {
        char **temp_uploaded_music_list = new char *[num_of_music_uploaded];
        int j = 0;
        for (int i = 0; i < num_of_music_uploaded; i++)
        {
            if ((strcmp(uploaded_music_list[i], music)))
            {
                temp_uploaded_music_list[j] = new char[strlen(uploaded_music_list[i])];
                strcpy(temp_uploaded_music_list[j], uploaded_music_list[i]);
                j++;
            }
            else
            {
                num_of_music_uploaded--;
            }
        }
        delete[] uploaded_music_list;
        uploaded_music_list = temp_uploaded_music_list;
    }
}

void ArtistUser::viewUploadedMusicList() const
{
    if (this->num_of_music_uploaded > 0)
    {
        for (int i = 0; i < this->num_of_music_uploaded; i++)
        {
            cout << (i + 1) << ". " << this->uploaded_music_list[i] << endl;
        }
    }
    else
    {
        cout << "No music uploaded" << endl;
    }
}

int ArtistUser::getNumOfMusicUploaded() const
{
    return this->num_of_music_uploaded;
}

int ArtistUser::getNumOfArtist()
{
    return ArtistUser::num_of_artist;
}